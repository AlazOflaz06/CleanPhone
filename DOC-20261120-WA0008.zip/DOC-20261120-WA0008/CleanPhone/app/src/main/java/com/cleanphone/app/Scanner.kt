package com.cleanphone.app

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

// ---------- Biçimlendirme ----------
fun fmtBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, u[i])
}

fun fmtDur(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) "${m / 60} sa ${m % 60} dk" else "$m dk"
}

fun fmtAgo(ts: Long): String {
    if (ts <= 0) return "30+ gün önce / hiç"
    val d = (System.currentTimeMillis() - ts) / 86_400_000L
    return when { d < 1 -> "bugün"; d == 1L -> "dün"; else -> "$d gün önce" }
}

// ---------- İzinler ----------
fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    else @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

fun hasFileAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

// ---------- Sistem bilgisi ----------
fun storageInfo(): Pair<Long, Long> {
    val s = StatFs(Environment.getDataDirectory().path)
    return s.availableBytes to s.totalBytes
}

fun ramInfo(ctx: Context): Pair<Long, Long> {
    val mi = ActivityManager.MemoryInfo()
    (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    return mi.availMem to mi.totalMem
}

// ---------- Uygulamalar ----------
class AppInfo(
    val label: String, val pkg: String,
    val fg7: Long,        // son 7 gün ekranda kalma süresi (ms)
    val svc7: Long,       // son 7 gün ön plan servisi (arka planda çalışan bildirimli servis) süresi (ms)
    val lastUsed: Long, val cache: Long, val size: Long,
    val isSys: Boolean
) {
    val load: Long get() = fg7 + (svc7 * 1.5).toLong()
}

private fun serviceTimes(usm: UsageStatsManager, from: Long, to: Long): Map<String, Long> {
    if (Build.VERSION.SDK_INT < 29) return emptyMap()
    val ev = usm.queryEvents(from, to)
    val e = UsageEvents.Event()
    val start = HashMap<String, Long>()
    val total = HashMap<String, Long>()
    while (ev.hasNextEvent()) {
        ev.getNextEvent(e)
        when (e.eventType) {
            19 -> start.putIfAbsent(e.packageName, e.timeStamp)            // FOREGROUND_SERVICE_START
            20 -> start.remove(e.packageName)?.let {                        // FOREGROUND_SERVICE_STOP
                total[e.packageName] = (total[e.packageName] ?: 0L) + (e.timeStamp - it)
            }
        }
    }
    for ((p, s) in start) total[p] = (total[p] ?: 0L) + (to - s)
    return total
}

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val now = System.currentTimeMillis()
    val day = 86_400_000L
    val has = hasUsageAccess(ctx)
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val stats30 = if (has) usm.queryAndAggregateUsageStats(now - 30 * day, now) else emptyMap()
    val stats7 = if (has) usm.queryAndAggregateUsageStats(now - 7 * day, now) else emptyMap()
    val svc = if (has) serviceTimes(usm, now - 7 * day, now) else emptyMap()
    val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
    val out = ArrayList<AppInfo>()
    for (pi in pm.getInstalledPackages(0)) {
        val ai = pi.applicationInfo ?: continue
        val pkg = pi.packageName
        if (pkg == ctx.packageName) continue
        var cache = 0L
        var size = 0L
        if (has) try {
            val st = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, Process.myUserHandle())
            cache = st.cacheBytes
            size = st.appBytes + st.dataBytes
        } catch (_: Exception) { }
        out += AppInfo(
            label = ai.loadLabel(pm).toString(), pkg = pkg,
            fg7 = stats7[pkg]?.totalTimeInForeground ?: 0L,
            svc7 = svc[pkg] ?: 0L,
            lastUsed = stats30[pkg]?.lastTimeUsed ?: 0L,
            cache = cache, size = size,
            isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        )
    }
    return out
}

// ---------- Gereksiz dosya taraması ----------
enum class Category(val title: String, val desc: String) {
    APK("Eski APK dosyaları", "Kurulumu bitmiş, artık gereksiz kurulum paketleri"),
    TEMP("Geçici / log / küçük resim önbelleği", "Uygulamaların geride bıraktığı .tmp, .log, .bak ve .thumbnails dosyaları"),
    DUP("Kopya dosyalar", "Aynı boyutta ve aynı içerikte olan dosyalar (ilk kopya korunur)"),
    EMPTY("Boş klasörler", "İçinde hiçbir şey olmayan klasörler"),
    LARGE("Büyük dosyalar (100 MB+)", "Silip silmemeye sen karar ver — varsayılan olarak seçili değil")
}

class JunkItem(val path: String, val size: Long, val cat: Category, sel: Boolean) {
    var selected by mutableStateOf(sel)
}

private val protectedDirs = setOf("Download", "DCIM", "Pictures", "Music", "Movies", "Documents",
    "Alarms", "Notifications", "Ringtones", "Podcasts")

private fun quickHash(f: File): String = try {
    RandomAccessFile(f, "r").use { r ->
        val md = MessageDigest.getInstance("MD5")
        val buf = ByteArray(65536)
        val len = r.length()
        for (pos in longArrayOf(0L, maxOf(0L, len / 2 - 32768), maxOf(0L, len - 65536))) {
            r.seek(pos)
            val n = r.read(buf)
            if (n > 0) md.update(buf, 0, n)
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }
} catch (e: Exception) { f.absolutePath }

fun scanJunk(): List<JunkItem> {
    val root = Environment.getExternalStorageDirectory()
    val out = ArrayList<JunkItem>()
    val bySize = HashMap<Long, MutableList<File>>()
    val big = 100L * 1024 * 1024

    fun walk(dir: File) {
        val kids = dir.listFiles() ?: return
        if (kids.isEmpty()) {
            val protectedRoot = dir.parentFile == root && dir.name in protectedDirs
            if (dir != root && !protectedRoot) out += JunkItem(dir.absolutePath, 0, Category.EMPTY, true)
            return
        }
        for (f in kids) {
            if (f.isDirectory) {
                if (dir == root && f.name == "Android") continue
                walk(f)
                continue
            }
            val n = f.name.lowercase()
            val len = f.length()
            when {
                n.endsWith(".apk") -> out += JunkItem(f.absolutePath, len, Category.APK, true)
                n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".log") || n.endsWith(".bak") ||
                    n.endsWith(".cache") || dir.name == ".thumbnails" ->
                    out += JunkItem(f.absolutePath, len, Category.TEMP, true)
                len >= big -> out += JunkItem(f.absolutePath, len, Category.LARGE, false)
                len >= 1_048_576L -> bySize.getOrPut(len) { ArrayList() }.add(f)
            }
        }
    }
    walk(root)

    for ((_, list) in bySize) {
        if (list.size < 2) continue
        val groups = HashMap<String, MutableList<File>>()
        for (f in list) groups.getOrPut(quickHash(f)) { ArrayList() }.add(f)
        for (g in groups.values) for (i in 1 until g.size)
            out += JunkItem(g[i].absolutePath, g[i].length(), Category.DUP, true)
    }
    return out.sortedByDescending { it.size }
}

fun deleteItems(items: List<JunkItem>): Pair<Long, Set<String>> {
    var freed = 0L
    val gone = HashSet<String>()
    for (i in items) {
        val f = File(i.path)
        if (!f.exists() || f.delete()) { freed += i.size; gone += i.path }
    }
    return freed to gone
}

// ---------- "Telefon neden yavaş?" tanılama ----------
class Finding(val title: String, val level: Int, val detail: String, val fix: String) // 0 iyi, 1 uyarı, 2 kötü

fun diagnose(ctx: Context, apps: List<AppInfo>): List<Finding> {
    val f = ArrayList<Finding>()
    val now = System.currentTimeMillis()
    val day = 86_400_000L
    val hasUsage = hasUsageAccess(ctx)

    // Depolama
    val (free, total) = storageInfo()
    val pct = (free * 100.0 / total).toInt()
    f += when {
        pct < 10 -> Finding("Depolama alanı kritik seviyede", 2,
            "Boş alan yalnızca %$pct (${fmtBytes(free)} / ${fmtBytes(total)}). Flash bellek dolmaya yaklaştıkça yazma işlemleri belirgin yavaşlar; sistem geçici dosya ve önbellek açacak yer bulmakta zorlanır, uygulamalar geç açılır, kamera ve güncellemeler takılır.",
            "Temizlik sekmesinden kopya, büyük ve gereksiz dosyaları sil; kullanmadığın uygulamaları kaldır. Hedef: en az %20 boş alan.")
        pct < 20 -> Finding("Depolama alanı azalıyor", 1,
            "Boş alan %$pct (${fmtBytes(free)} / ${fmtBytes(total)}). %15-20 altına inen depolama, flash belleğin 'çöp toplama' işlemini yavaşlatır ve telefonda hissedilir gecikme yaratır.",
            "Temizlik sekmesindeki önerileri uygula; fotoğraf/videoları buluta yedekleyip cihazdan sil.")
        else -> Finding("Depolama alanı yeterli", 0, "Boş alan %$pct (${fmtBytes(free)} / ${fmtBytes(total)}).", "Bir şey yapmana gerek yok.")
    }

    // RAM
    val (avail, ram) = ramInfo(ctx)
    val rp = (avail * 100.0 / ram).toInt()
    val ramGb = ram / 1024.0 / 1024 / 1024
    f += when {
        ramGb < 3.0 -> Finding("RAM miktarı düşük", 1,
            "Toplam RAM ${String.format(Locale.US, "%.1f", ramGb)} GB, şu an %$rp boş. Modern Android ve uygulamaları 4 GB altında sık sık arka plandaki uygulamaları kapatıp yeniden açmak zorunda kalır; bu da uygulama geçişlerinde yavaşlık olarak görünür.",
            "Aynı anda az uygulama kullan, ağır uygulamaların 'Lite' sürümlerini tercih et, kullanılmayan uygulamaları kaldır.")
        rp < 10 -> Finding("Boş RAM çok az", 1,
            "Şu an RAM'in yalnızca %$rp kadarı boş (${fmtBytes(avail)} / ${fmtBytes(ram)}). Android RAM'i bilerek doldurur, bu tek başına sorun değildir; ama arka planda çok uygulama varsa sistem sürekli uygulama öldürüp yeniden başlatır.",
            "Telefonu yeniden başlat ve arka plan servisi çok çalışan uygulamaları (Pil sekmesi) kontrol et.")
        else -> Finding("RAM durumu normal", 0, "RAM ${String.format(Locale.US, "%.1f", ramGb)} GB, boş yaklaşık %$rp.", "Bir şey yapmana gerek yok.")
    }

    // Android sürümü / güvenlik yaması
    val patch = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)?.time } catch (e: Exception) { null }
    val months = if (patch != null) (now - patch) / (30L * day) else 0L
    f += if (Build.VERSION.SDK_INT < 30 || months >= 12)
        Finding("Yazılım eski", 1,
            "Android ${Build.VERSION.RELEASE}, güvenlik yaması ${Build.VERSION.SECURITY_PATCH} (~$months ay önce). Yeni uygulamalar yeni Android sürümleri için optimize edilir; eski sürümlerde performans iyileştirmeleri ve hata düzeltmeleri eksik kalır.",
            "Ayarlar > Sistem > Yazılım güncelleme bölümünden güncelleme olup olmadığına bak.")
    else Finding("Yazılım güncel görünüyor", 0, "Android ${Build.VERSION.RELEASE}, güvenlik yaması ${Build.VERSION.SECURITY_PATCH}.", "Bir şey yapmana gerek yok.")

    // Açık kalma süresi
    val upDays = SystemClock.elapsedRealtime() / day
    f += if (upDays >= 5)
        Finding("Telefon uzun süredir yeniden başlatılmadı", 1,
            "$upDays gündür kapanmadı. Uzun açık kalan sistemde bellek parçalanır, sızıntı yapan uygulamalar RAM'i tüketir ve arka plan işlemleri birikir.",
            "Telefonu yeniden başlat. Haftada bir yeniden başlatmak çoğu zaman gözle görülür hız kazandırır.")
    else Finding("Yeniden başlatma durumu iyi", 0, "Telefon $upDays gündür açık.", "Bir şey yapmana gerek yok.")

    // Animasyon ölçeği
    val anim = try { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) } catch (e: Exception) { 1f }
    if (anim > 1f) f += Finding("Animasyonlar yavaşlatılmış", 1,
        "Geliştirici ayarlarında animasyon ölçeği ${anim}x. Geçişler olduğundan uzun sürer ve telefon yavaş hissettirir.",
        "Ayarlar > Geliştirici seçenekleri > Animasyon ölçeğini 1x veya 0.5x yap.")

    // Uygulama sayısı ve kullanılmayanlar
    val user = apps.filter { !it.isSys }
    if (user.size > 80) f += Finding("Çok fazla uygulama yüklü", 1,
        "${user.size} adet kullanıcı uygulaması var. Her uygulama arka planda senkronizasyon, bildirim ve otomatik başlatma kayıtları bırakır; sayı arttıkça sistem kaynakları bölüşülür.",
        "Kullanmadıklarını Temizlik sekmesinden kaldır.")
    if (hasUsage) {
        val unused = user.filter { it.lastUsed == 0L || now - it.lastUsed > 30 * day }
        if (unused.size >= 5) f += Finding("30 gündür açılmayan ${unused.size} uygulama var", 1,
            "Bu uygulamalar toplam ${fmtBytes(unused.sumOf { it.size })} yer kaplıyor ve arka planda güncelleme/senkronizasyon yapabiliyor.",
            "Temizlik sekmesindeki 'Kaldırılması önerilen uygulamalar' listesinden kaldır.")
        val cacheTotal = apps.sumOf { it.cache }
        if (cacheTotal > 1024L * 1024 * 1024) f += Finding("Uygulama önbelleği şişmiş", if (cacheTotal > 3L * 1024 * 1024 * 1024) 2 else 1,
            "Toplam önbellek ${fmtBytes(cacheTotal)}. Önbellek hız için vardır, ama aşırı büyüdüğünde depolamayı doldurur ve bozuk önbellek takılmaya yol açabilir.",
            "Temizlik sekmesinde en büyük önbellekli uygulamaların 'Depolama' sayfasından önbelleği temizle.")
        val heavy = apps.filter { it.svc7 > 3L * 3_600_000 }.sortedByDescending { it.svc7 }.take(3)
        if (heavy.isNotEmpty()) f += Finding("Arka planda sürekli çalışan uygulamalar", 1,
            "Son 7 günde uzun süre bildirimli arka plan servisi çalıştıranlar: " +
                heavy.joinToString { "${it.label} (${fmtDur(it.svc7)})" } + ". Bunlar hem CPU hem pil tüketir.",
            "Pil sekmesinden uygulama ayarlarına gir; gerekmiyorsa arka plan kullanımını kısıtla veya kaldır.")
    } else {
        f += Finding("Kullanım erişimi verilmedi", 1,
            "Uygulama bazlı analiz (arka plan, önbellek, kullanılmayanlar) için 'Kullanım erişimi' izni gerekir.",
            "Ana sayfadaki 'İzin ver' düğmesine dokun ve Clean Phone için aç.")
    }

    // Pil, ısı, güç tasarrufu
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val health = bi?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
    val badHealth = health == BatteryManager.BATTERY_HEALTH_OVERHEAT || health == BatteryManager.BATTERY_HEALTH_DEAD ||
        health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE || health == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE
    val thermal = Build.VERSION.SDK_INT >= 29 && pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
    f += when {
        badHealth -> Finding("Pil sağlığı sorunlu", 2,
            "Sistem pil durumunu sağlıksız bildiriyor. Yıpranmış pil voltaj düşüşü yapar; işlemci kendini koruma için yavaşlatılır (performans kısıtlaması).",
            "Pil değişimi için yetkili servise başvur.")
        temp >= 40f || thermal -> Finding("Telefon ısınmış (işlemci kısılıyor olabilir)", if (temp >= 45f) 2 else 1,
            "Pil sıcaklığı ${String.format(Locale.US, "%.1f", temp)}°C. Isınan işlemci kendini korumak için hızını düşürür (termal kısma) ve bu doğrudan takılma olarak görünür.",
            "Kılıfı çıkar, şarj sırasında ağır uygulama kullanma, doğrudan güneşten koru.")
        else -> Finding("Pil ve ısı normal", 0, "Sıcaklık ${String.format(Locale.US, "%.1f", temp)}°C.", "Bir şey yapmana gerek yok.")
    }
    if (pm.isPowerSaveMode) f += Finding("Pil tasarrufu modu açık", 1,
        "Pil tasarrufu işlemci hızını, animasyonları ve arka plan işlerini kısıtlar; telefon bilerek yavaşlatılmıştır.",
        "Şarjın yeterliyse pil tasarrufunu kapat.")
    return f
}
