package com.cleanphone.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

val Teal = Color(0xFF00BFA5)
val Blue = Color(0xFF1565C0)
private val Red = Color(0xFFD32F2F)
private val Amber = Color(0xFFFFA000)

private fun safeStart(ctx: Context, i: Intent) {
    try { ctx.startActivity(i) } catch (e: Exception) {
        Toast.makeText(ctx, "Bu ayar sayfası açılamadı", Toast.LENGTH_SHORT).show()
    }
}

private fun appSettings(ctx: Context, pkg: String) =
    safeStart(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

@Composable
fun CleanPhoneApp(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var bump by remember { mutableIntStateOf(0) }
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var findings by remember { mutableStateOf(emptyList<Finding>()) }
    val junk = remember { mutableStateListOf<JunkItem>() }
    var scanning by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val usage = remember(tick, bump) { hasUsageAccess(ctx) }
    val files = remember(tick, bump) { hasFileAccess(ctx) }
    val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { bump++ }

    LaunchedEffect(tick, bump) {
        val r = withContext(Dispatchers.IO) { val a = loadApps(ctx); Pair(a, diagnose(ctx, a)) }
        apps = r.first
        findings = r.second
    }

    fun openUsage() = safeStart(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    fun openFiles() {
        if (Build.VERSION.SDK_INT >= 30)
            safeStart(ctx, Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        else legacy.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }
    fun scan() {
        if (!files) { openFiles(); return }
        if (scanning) return
        scanning = true
        tab = 1
        scope.launch {
            val r = withContext(Dispatchers.IO) { scanJunk() }
            junk.clear(); junk.addAll(r)
            scanning = false; scanned = true
        }
    }

    val tabs = listOf(
        "Ana Sayfa" to Icons.Filled.Home,
        "Temizlik" to Icons.Filled.CleaningServices,
        "Pil" to Icons.Filled.BatteryAlert,
        "Yavaşlık" to Icons.Filled.Speed
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Teal)) {
        Scaffold(bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) })
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(findings, usage, files, ::openUsage, ::openFiles, ::scan) { tab = 3 }
                    1 -> CleanScreen(junk, scanning, scanned, files, apps, ::scan, ::openFiles) { confirm = true }
                    2 -> BatteryScreen(apps, usage, ::openUsage)
                    else -> SlowScreen(findings)
                }
            }
        }

        if (confirm) {
            val sel = junk.filter { it.selected }
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text("Silinsin mi?") },
                text = { Text("${sel.size} öğe (${fmtBytes(sel.sumOf { it.size })}) kalıcı olarak silinecek. Bu işlem geri alınamaz.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirm = false
                        scope.launch {
                            val (freed, gone) = withContext(Dispatchers.IO) { deleteItems(sel) }
                            junk.removeAll { it.path in gone }
                            Toast.makeText(ctx, "${fmtBytes(freed)} yer açıldı", Toast.LENGTH_LONG).show()
                            bump++
                        }
                    }) { Text("Sil", color = Red) }
                },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Vazgeç") } }
            )
        }
    }
}

// ---------- Ortak parçalar ----------
@Composable
private fun InfoCard(text: String, bg: Color = Color(0xFFE3F2FD)) {
    Card(colors = CardDefaults.cardColors(containerColor = bg), modifier = Modifier.fillMaxWidth()) {
        Text(text, Modifier.padding(14.dp), fontSize = 13.sp)
    }
}

@Composable
private fun PermCard(text: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, fontSize = 13.sp)
            Button(onClick = onClick) { Text(button) }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, progress: Float) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, fontSize = 13.sp)
            LinearProgressIndicator(progress = progress.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
        }
    }
}

// ---------- Ana sayfa ----------
@Composable
fun HomeScreen(
    findings: List<Finding>, usage: Boolean, files: Boolean,
    onUsage: () -> Unit, onFiles: () -> Unit, onScan: () -> Unit, onSlow: () -> Unit
) {
    val ctx = LocalContext.current
    val (free, total) = storageInfo()
    val (avail, ram) = ramInfo(ctx)
    val penalty = findings.sumOf { when (it.level) { 2 -> 15; 1 -> 7; else -> 0 } }
    val score = (100 - penalty).coerceIn(5, 100)
    val ringColor = if (score >= 75) Teal else if (score >= 50) Amber else Red

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Clean Phone", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Blue)
        Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(progress = score / 100f, modifier = Modifier.fillMaxSize(), strokeWidth = 12.dp, color = ringColor)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$score", fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Text("Sağlık puanı", fontSize = 12.sp)
            }
        }
        if (!files) PermCard("Gereksiz dosyaları tarayabilmek için 'Tüm dosyalara erişim' izni gerekir.", "Dosya iznini ver", onFiles)
        if (!usage) PermCard("Arka plan ve pil analizi için 'Kullanım erişimi' izni gerekir.", "Kullanım iznini ver", onUsage)
        Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Text("Tara ve temizle") }
        OutlinedButton(onClick = onSlow, modifier = Modifier.fillMaxWidth()) { Text("Telefon neden yavaş? (detaylı rapor)") }
        StatCard("Depolama", "${fmtBytes(total - free)} kullanılıyor / ${fmtBytes(total)}", (total - free).toFloat() / total)
        StatCard("RAM", "${fmtBytes(ram - avail)} kullanılıyor / ${fmtBytes(ram)}", (ram - avail).toFloat() / ram)
        val bad = findings.count { it.level == 2 }
        val warn = findings.count { it.level == 1 }
        InfoCard("Tespit edilen: $bad kritik, $warn uyarı. Ayrıntılar 'Yavaşlık' sekmesinde.")
    }
}

// ---------- Temizlik ----------
@Composable
fun CleanScreen(
    junk: SnapshotStateList<JunkItem>, scanning: Boolean, scanned: Boolean, files: Boolean,
    apps: List<AppInfo>, onScan: () -> Unit, onFiles: () -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val now = System.currentTimeMillis()
    val sel = junk.filter { it.selected }
    val unused = apps.filter { !it.isSys && (it.lastUsed == 0L || now - it.lastUsed > 30L * 86_400_000L) && it.size > 0 }
        .sortedByDescending { it.size }.take(15)
    val bigCache = apps.filter { it.cache > 20L * 1024 * 1024 }.sortedByDescending { it.cache }.take(10)

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Temizlik", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            item {
                if (!files) PermCard("Dosya taraması için 'Tüm dosyalara erişim' izni gerekir.", "İzin ver", onFiles)
                else Button(onClick = onScan, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
                    Text(if (scanning) "Taranıyor..." else if (scanned) "Yeniden tara" else "Dosyaları tara")
                }
            }
            if (scanned && junk.isEmpty()) item { InfoCard("Silinecek gereksiz dosya bulunamadı.", Color(0xFFE8F5E9)) }

            for (c in Category.values()) {
                val list = junk.filter { it.cat == c }
                if (list.isEmpty()) continue
                item(key = "h_" + c.name) {
                    Column(Modifier.padding(top = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.title, fontWeight = FontWeight.SemiBold)
                                Text("${list.size} öğe • ${fmtBytes(list.sumOf { it.size })}", fontSize = 12.sp, color = Color.Gray)
                            }
                            val all = list.all { it.selected }
                            TextButton(onClick = { list.forEach { it.selected = !all } }) { Text(if (all) "Seçimi kaldır" else "Hepsini seç") }
                        }
                        Text(c.desc, fontSize = 12.sp, color = Color.Gray)
                    }
                }
                items(list.take(60), key = { it.path }) { j ->
                    val file = File(j.path)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = j.selected, onCheckedChange = { j.selected = it })
                        Column(Modifier.weight(1f)) {
                            Text(file.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(file.parent ?: "", fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(fmtBytes(j.size), fontSize = 12.sp)
                    }
                }
                if (list.size > 60) item(key = "m_" + c.name) { Text("... ve ${list.size - 60} öğe daha (hepsi seçim durumuna dahildir)", fontSize = 12.sp, color = Color.Gray) }
            }

            item { Text("Kaldırılması önerilen uygulamalar", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp)) }
            item { Text("30 gündür hiç açılmamış, en çok yer kaplayanlar. (Kullanım erişimi gerekir)", fontSize = 12.sp, color = Color.Gray) }
            if (unused.isEmpty()) item { Text("Öneri yok.", fontSize = 13.sp) }
            items(unused, key = { "u_" + it.pkg }) { a ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${fmtBytes(a.size)} • son kullanım: ${fmtAgo(a.lastUsed)}", fontSize = 11.sp, color = Color.Gray)
                    }
                    TextButton(onClick = { safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))) }) { Text("Kaldır", color = Red) }
                }
            }

            item { Text("Önbelleği şişmiş uygulamalar", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp)) }
            item { Text("Android, başka uygulamanın önbelleğini silmeye izin vermez; 'Depolama' sayfasından 'Önbelleği temizle'ye dokun.", fontSize = 12.sp, color = Color.Gray) }
            if (bigCache.isEmpty()) item { Text("Öneri yok.", fontSize = 13.sp) }
            items(bigCache, key = { "c_" + it.pkg }) { a ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Önbellek: ${fmtBytes(a.cache)}", fontSize = 11.sp, color = Color.Gray)
                    }
                    TextButton(onClick = { appSettings(ctx, a.pkg) }) { Text("Depolama") }
                }
            }
            item {
                OutlinedButton(onClick = {
                    ctx.cacheDir.deleteRecursively()
                    Toast.makeText(ctx, "Clean Phone önbelleği temizlendi", Toast.LENGTH_SHORT).show()
                }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("Clean Phone önbelleğini temizle") }
            }
        }
        if (sel.isNotEmpty()) {
            Button(onClick = onDelete, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text("Seçilenleri sil (${sel.size} • ${fmtBytes(sel.sumOf { it.size })})")
            }
        }
    }
}

// ---------- Pil / arka plan ----------
@Composable
fun BatteryScreen(apps: List<AppInfo>, usage: Boolean, onUsage: () -> Unit) {
    val ctx = LocalContext.current
    val list = apps.filter { it.load > 0 }.sortedByDescending { it.load }.take(40)
    val total = list.sumOf { it.load }.coerceAtLeast(1L)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Arka plan ve güç tüketimi", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            InfoCard("Son 7 gün: ekranda kalma süresi ve bildirimli arka plan servisi süresine göre her uygulamanın tahmini yük payı. " +
                "Kesin mAh değerlerini yalnızca Android'in kendi Pil ekranı verir; Android bunu üçüncü taraf uygulamalara açmaz.")
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { safeStart(ctx, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }) { Text("Sistem pil ayarları", fontSize = 12.sp) }
                OutlinedButton(onClick = { safeStart(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Pil optimizasyonu", fontSize = 12.sp) }
            }
        }
        if (!usage) item { PermCard("Bu liste için 'Kullanım erişimi' izni gerekir.", "İzin ver", onUsage) }
        items(list, key = { it.pkg }) { a ->
            val share = a.load.toFloat() / total
            val label = if (share > 0.15f) "Yüksek" else if (share > 0.05f) "Orta" else "Düşük"
            val color = if (share > 0.15f) Red else if (share > 0.05f) Amber else Teal
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(a.label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("$label • %${(share * 100).toInt()}", color = color, fontSize = 12.sp)
                    }
                    LinearProgressIndicator(progress = share, modifier = Modifier.fillMaxWidth(), color = color)
                    Text("Ekranda: ${fmtDur(a.fg7)}   •   Arka plan servisi: ${fmtDur(a.svc7)}", fontSize = 12.sp)
                    Text("Son kullanım: ${fmtAgo(a.lastUsed)}   •   Önbellek: ${fmtBytes(a.cache)}", fontSize = 12.sp, color = Color.Gray)
                    TextButton(onClick = { appSettings(ctx, a.pkg) }) { Text("Uygulama ayarları (kısıtla / kaldır)") }
                }
            }
        }
    }
}

// ---------- Neden yavaş ----------
private val generalReasons = listOf(
    "Depolama dolduğunda" to "Flash bellek (UFS/eMMC) boş blok bulmakta zorlanır; her yazma işlemi önce eski veriyi silmeyi gerektirir. Telefonun %80-90'ı dolunca hem uygulama açılışı hem kamera hem de güncellemeler gözle görülür yavaşlar.",
    "Arka plan uygulamaları" to "Sosyal medya, haber ve alışveriş uygulamaları arka planda senkronizasyon, konum ve reklam servisleri çalıştırır. Hepsi CPU, RAM ve ağ kullanır; telefon 'boştayken' bile çalışır.",
    "Yıpranan pil" to "Pil yaşlandıkça voltajı düşer. Telefon ani yük altında kapanmasın diye işlemciyi bilerek kısabilir. 2 yıllık pillerde bu çok yaygındır.",
    "Isınma (termal kısma)" to "İşlemci ısınınca kendini korumak için hızını düşürür. Şarjda oyun, güneşte navigasyon, kalın kılıf ısıyı artırır ve takılma yaratır.",
    "Yazılımların ağırlaşması" to "Uygulamalar ve Android her sürümde daha çok kaynak ister. 3-4 yıllık bir cihaz, yeni nesil uygulamaların gereksinimine yetişmekte zorlanır.",
    "Önbellek ve artık dosyalar" to "Önbellek hız kazandırmak içindir ama çok şişince depolamayı doldurur; bozulan önbellek uygulamanın çökmesine ya da geç açılmasına yol açar.",
    "Uzun süre kapatmamak" to "Haftalarca açık kalan sistemde bellek parçalanır, sızıntı yapan uygulamalar RAM'i yer. Yeniden başlatma bunların hepsini sıfırlar.",
    "Widget, canlı duvar kâğıdı, animasyonlar" to "Sürekli güncellenen widget'lar ve canlı duvar kâğıtları ana ekranda her zaman işlemci ve GPU kullanır.",
    "Görev öldürücü uygulamalar" to "'RAM boşalt' uygulamaları genelde ters etki yapar: kapatılan uygulamalar hemen yeniden başlar ve bu açılış, onları bellekte tutmaktan çok daha fazla işlemci ve pil harcar. Clean Phone bunu bilerek yapmaz."
)

@Composable
fun SlowScreen(findings: List<Finding>) {
    val sorted = findings.sortedByDescending { it.level }
    val bad = sorted.filter { it.level == 2 }
    val warn = sorted.filter { it.level == 1 }
    val verdict = when {
        bad.isNotEmpty() -> "Telefonunun yavaşlamasının ana nedenleri: " + bad.joinToString(", ") { it.title.lowercase() } + ". Önce bunları çöz."
        warn.isNotEmpty() -> "Ciddi bir arıza görünmüyor ama " + warn.size + " uyarı yavaşlığa katkı yapıyor olabilir. Aşağıdaki çözümleri sırayla dene."
        else -> "Sistem sağlıklı görünüyor. Yavaşlık sürüyorsa donanım yaşı veya tek bir ağır uygulama olabilir; Pil sekmesindeki listeye bak."
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Telefon neden yavaş?", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard(verdict) }
        items(sorted, key = { it.title }) { x ->
            val bg = when (x.level) { 2 -> Color(0xFFFFEBEE); 1 -> Color(0xFFFFF8E1); else -> Color(0xFFE8F5E9) }
            val mark = when (x.level) { 2 -> "🔴"; 1 -> "🟡"; else -> "🟢" }
            Card(colors = CardDefaults.cardColors(containerColor = bg), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("$mark  ${x.title}", fontWeight = FontWeight.SemiBold)
                    Text(x.detail, fontSize = 13.sp)
                    if (x.level > 0) Text("Çözüm: " + x.fix, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
        item { Text("Telefonlar zamanla neden yavaşlar?", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 14.dp)) }
        items(generalReasons, key = { it.first }) { (t, d) ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(t, fontWeight = FontWeight.SemiBold)
                    Text(d, fontSize = 13.sp)
                }
            }
        }
    }
}
