# Clean Phone (Android)

## APK nasıl oluşturulur
1. Android Studio'yu indir (Koala 2024.1 veya yeni): https://developer.android.com/studio
2. File > Open > bu `CleanPhone` klasörünü seç. Gradle 8.7 indirmeyi isterse kabul et, "Sync" bitsin.
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. Dosya: app/build/outputs/apk/debug/app-debug.apk -> telefona at, kur (bilinmeyen kaynaklara izin ver).

## İlk açılışta izinler
- "Kullanım erişimi" (uygulama / arka plan / önbellek analizi)
- "Tüm dosyalara erişim" (gereksiz dosya taraması ve silme)
